#include <iostream>
#include <array>
#include <cmath>

using namespace std;
class bag
{
protected:
    array<float, 25> a;
    int n;

public:
    bag()
    {
        n = 0;
    }
    void populate(int num)
    {
        cout << "yes" << endl;
        for (int i = 0; i < num; i++)
        {
            if (i == 0)
            {
                a[i] = 0;
            }
            else
            {
                a[i] = (1 / double(i));
            }
        }
    }
    void insert(float f, int num)
    {
        cout << "yes" << endl;
        for (int i = 0; i > n; i++)
        {
            if (i >= num)
            {
                a[i + 1] = a[i];
            }
        }
        num++;
    }
    float extract(int num)
    {
        cout << "yes" << endl;
        float temp = a[num];
        for (int i = num; i < n; i++)
        {
            a[i] = a[i + 1];
        }
        num--;
        return temp;
    }
    friend ostream &operator<<(ostream &s, const bag &b)
    {
        for (int j = 0; j < b.n; j++)
        {
            cout << b.a[j] << ",";
            s << b.a[j] << ",";
        }
        return s;
    }
};
int main()
{
    array<float, 25> a;
    int n;
    cout << "Enter number:";
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        if (i == 0)
        {
            a[i] = 0;
        }
        else
        {
            a[i] = (1 / double(i));
        }
    }
    for (int j = 0; j < n; j++)
    {
        cout << a[j] << ",";
    }
    cout << endl;
    int n2;
    cout << "Enter number:";
    cin >> n2;
    int temp = a[n2];
    a[n2] = a[n - 1];
    a[n - 1] = temp;
    for (int j = 0; j < n; j++)
    {
        cout << a[j] << ",";
    }
    cout << endl;
    int n3;
    cout << "Enter number:";
    cin >> n3;
    for (int i = 0; i > n; i++)
    {
        if (i >= n3)
        {
            a[i + 1] = a[i];
        }
    }
    a[n3] = n3 * n3;
    n = n + 1;
    for (int j = 0; j < n + 1; j++)
    {
        cout << a[j] << ",";
    }
    cout << endl;
    int m = n / 2 + 1;
    for (int i = m; i < n; i++)
    {
        a[i] = a[i + 1];
    }
    n = n - 1;
    for (int j = 0; j < n; j++)
    {
        cout << a[j] << ",";
    }
    cout << endl;
    // bag b;
    // b.populate(12);
    // b.insert(3.14, 5);
    // b.extract(5);
    // cout << b;
    // cout << 2;
    return 0;
}
